#!/bin/bash
clear
npm install
nodemon index.js
