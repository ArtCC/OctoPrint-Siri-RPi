#!/bin/bash
clear
echo 'Installing dependencies...'
npm install
echo 'API REST for Siri is up. Close this terminal with your OctoPrint server without canceling Nodemon. Enjoy!'
nodemon index.js
